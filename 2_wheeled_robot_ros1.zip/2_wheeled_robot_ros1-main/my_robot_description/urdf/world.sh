<sdf version='1.7'>
  <world name='default'>
    <light name='sun' type='directional'>
      <cast_shadows>1</cast_shadows>
      <pose>0 0 10 0 -0 0</pose>
      <diffuse>0.8 0.8 0.8 1</diffuse>
      <specular>0.2 0.2 0.2 1</specular>
      <attenuation>
        <range>1000</range>
        <constant>0.9</constant>
        <linear>0.01</linear>
        <quadratic>0.001</quadratic>
      </attenuation>
      <direction>-0.5 0.1 -0.9</direction>
      <spot>
        <inner_angle>0</inner_angle>
        <outer_angle>0</outer_angle>
        <falloff>0</falloff>
      </spot>
    </light>
    <model name='ground_plane'>
      <static>1</static>
      <link name='link'>
        <collision name='collision'>
          <geometry>
            <plane>
              <normal>0 0 1</normal>
              <size>100 100</size>
            </plane>
          </geometry>
          <surface>
            <contact>
              <collide_bitmask>65535</collide_bitmask>
              <ode/>
            </contact>
            <friction>
              <ode>
                <mu>100</mu>
                <mu2>50</mu2>
              </ode>
              <torsional>
                <ode/>
              </torsional>
            </friction>
            <bounce/>
          </surface>
          <max_contacts>10</max_contacts>
        </collision>
        <visual name='visual'>
          <cast_shadows>0</cast_shadows>
          <geometry>
            <plane>
              <normal>0 0 1</normal>
              <size>100 100</size>
            </plane>
          </geometry>
          <material>
            <script>
              <uri>file://media/materials/scripts/gazebo.material</uri>
              <name>Gazebo/Grey</name>
            </script>
          </material>
        </visual>
        <self_collide>0</self_collide>
        <enable_wind>0</enable_wind>
        <kinematic>0</kinematic>
      </link>
    </model>
    <gravity>0 0 -9.8</gravity>
    <magnetic_field>6e-06 2.3e-05 -4.2e-05</magnetic_field>
    <atmosphere type='adiabatic'/>
    <physics type='ode'>
      <max_step_size>0.001</max_step_size>
      <real_time_factor>1</real_time_factor>
      <real_time_update_rate>1000</real_time_update_rate>
    </physics>
    <scene>
      <ambient>0.4 0.4 0.4 1</ambient>
      <background>0.7 0.7 0.7 1</background>
      <shadows>1</shadows>
    </scene>
    <wind/>
    <spherical_coordinates>
      <surface_model>EARTH_WGS84</surface_model>
      <latitude_deg>0</latitude_deg>
      <longitude_deg>0</longitude_deg>
      <elevation>0</elevation>
      <heading_deg>0</heading_deg>
    </spherical_coordinates>
    <model name='my_robot'>
      <link name='base_footprint'>
        <inertial>
          <pose>0.0365 0 0.039673 0 -0 0</pose>
          <mass>0.26</mass>
          <inertia>
            <ixx>0.000321609</ixx>
            <ixy>0</ixy>
            <ixz>-6.42075e-05</ixz>
            <iyy>0.00113205</iyy>
            <iyz>0</iyz>
            <izz>0.0010641</izz>
          </inertia>
        </inertial>
        <collision name='base_footprint_fixed_joint_lump__chassis_collision'>
          <pose>0 0 0.032 0 -0 0</pose>
          <geometry>
            <mesh>
              <scale>1 1 1</scale>
              <uri>/root/catkin_ws/src/my_ROS_mobile_robot/my_robot_description/meshes/chassis.dae</uri>
            </mesh>
          </geometry>
          <surface>
            <contact>
              <ode/>
            </contact>
            <friction>
              <ode>
                <mu>0.3</mu>
                <mu2>0.3</mu2>
              </ode>
              <torsional>
                <ode/>
              </torsional>
            </friction>
            <bounce/>
          </surface>
          <max_contacts>10</max_contacts>
        </collision>
        <collision name='base_footprint_fixed_joint_lump__camera_link_collision_1'>
          <pose>0.095 0 0.06 0 -0 0</pose>
          <geometry>
            <box>
              <size>0.04 0.08 0.03</size>
            </box>
          </geometry>
          <surface>
            <contact>
              <ode/>
            </contact>
            <friction>
              <ode>
                <mu>0.2</mu>
                <mu2>0.2</mu2>
              </ode>
              <torsional>
                <ode/>
              </torsional>
            </friction>
            <bounce/>
          </surface>
          <max_contacts>10</max_contacts>
        </collision>
        <collision name='base_footprint_fixed_joint_lump__caster_wheel_collision_2'>
          <pose>0.091 0 0.042 0 -0 0</pose>
          <geometry>
            <mesh>
              <scale>1 1 1</scale>
              <uri>/root/catkin_ws/src/my_ROS_mobile_robot/my_robot_description/meshes/caster_wheel.dae</uri>
            </mesh>
          </geometry>
          <surface>
            <contact>
              <ode>
                <kp>1e+06</kp>
                <kd>100</kd>
                <max_vel>1</max_vel>
                <min_depth>0.001</min_depth>
              </ode>
            </contact>
            <friction>
              <ode>
                <mu>0</mu>
                <mu2>0</mu2>
              </ode>
              <torsional>
                <ode/>
              </torsional>
            </friction>
            <bounce/>
          </surface>
          <max_contacts>10</max_contacts>
        </collision>
        <collision name='base_footprint_fixed_joint_lump__hokuyo_link_collision_3'>
          <pose>0.035 0 0.1135 0 -0 0</pose>
          <geometry>
            <box>
              <size>0.05 0.05 0.07</size>
            </box>
          </geometry>
          <surface>
            <contact>
              <ode/>
            </contact>
            <friction>
              <ode/>
              <torsional>
                <ode/>
              </torsional>
            </friction>
            <bounce/>
          </surface>
          <max_contacts>10</max_contacts>
        </collision>
        <visual name='base_footprint_fixed_joint_lump__chassis_visual'>
          <pose>0 0 0.032 0 -0 0</pose>
          <geometry>
            <mesh>
              <scale>1 1 1</scale>
              <uri>/root/catkin_ws/src/my_ROS_mobile_robot/my_robot_description/meshes/chassis.dae</uri>
            </mesh>
          </geometry>
          <material>
            <script>
              <name>Gazebo/Red</name>
              <uri>file://media/materials/scripts/gazebo.material</uri>
            </script>
          </material>
        </visual>
        <visual name='base_footprint_fixed_joint_lump__camera_link_visual_1'>
          <pose>0.095 0 0.06 0 -0 0</pose>
          <geometry>
            <box>
              <size>0.04 0.08 0.03</size>
            </box>
          </geometry>
          <material>
            <script>
              <name>Gazebo/Green</name>
              <uri>file://media/materials/scripts/gazebo.material</uri>
            </script>
          </material>
        </visual>
        <visual name='base_footprint_fixed_joint_lump__caster_wheel_visual_2'>
          <pose>0.091 0 0.042 0 -0 0</pose>
          <geometry>
            <mesh>
              <scale>1 1 1</scale>
              <uri>/root/catkin_ws/src/my_ROS_mobile_robot/my_robot_description/meshes/caster_wheel.dae</uri>
            </mesh>
          </geometry>
          <material>
            <script>
              <name>Gazebo/Chrome</name>
              <uri>file://media/materials/scripts/gazebo.material</uri>
            </script>
          </material>
        </visual>
        <visual name='base_footprint_fixed_joint_lump__hokuyo_link_visual_3'>
          <pose>0.035 0 0.1135 0 -0 0</pose>
          <geometry>
            <mesh>
              <scale>1 1 1</scale>
              <uri>/root/catkin_ws/src/my_ROS_mobile_robot/my_robot_description/meshes/hokuyo.dae</uri>
            </mesh>
          </geometry>
        </visual>
        <sensor name='camera1' type='camera'>
          <update_rate>30</update_rate>
          <camera name='head'>
            <horizontal_fov>1.39626</horizontal_fov>
            <image>
              <width>800</width>
              <height>800</height>
              <format>R8G8B8</format>
            </image>
            <clip>
              <near>0.02</near>
              <far>300</far>
            </clip>
          </camera>
          <plugin name='camera_controller' filename='libgazebo_ros_camera.so'>
            <alwaysOn>1</alwaysOn>
            <updateRate>0.0</updateRate>
            <cameraName>my_robot/camera1</cameraName>
            <imageTopicName>image_raw</imageTopicName>
            <cameraInfoTopicName>camera_info</cameraInfoTopicName>
            <frameName>camera_link</frameName>
            <hackBaseline>0.07</hackBaseline>
            <distortionK1>0.0</distortionK1>
            <distortionK2>0.0</distortionK2>
            <distortionK3>0.0</distortionK3>
            <distortionT1>0.0</distortionT1>
            <distortionT2>0.0</distortionT2>
            <robotNamespace>/</robotNamespace>
          </plugin>
          <pose>0.095 0 0.06 0 -0 0</pose>
        </sensor>
        <sensor name='camera1' type='camera'>
          <update_rate>30</update_rate>
          <camera name='head'>
            <horizontal_fov>1.39626</horizontal_fov>
            <image>
              <width>800</width>
              <height>800</height>
              <format>R8G8B8</format>
            </image>
            <clip>
              <near>0.02</near>
              <far>300</far>
            </clip>
          </camera>
          <plugin name='camera_controller' filename='libgazebo_ros_camera.so'>
            <alwaysOn>1</alwaysOn>
            <updateRate>0.0</updateRate>
            <cameraName>my_robot/camera1</cameraName>
            <imageTopicName>image_raw</imageTopicName>
            <cameraInfoTopicName>camera_info</cameraInfoTopicName>
            <frameName>camera_link</frameName>
            <hackBaseline>0.07</hackBaseline>
            <distortionK1>0.0</distortionK1>
            <distortionK2>0.0</distortionK2>
            <distortionK3>0.0</distortionK3>
            <distortionT1>0.0</distortionT1>
            <distortionT2>0.0</distortionT2>
            <robotNamespace>/</robotNamespace>
          </plugin>
          <pose>0.095 0 0.06 0 -0 0</pose>
        </sensor>
        <sensor name='head_hokuyo_sensor' type='ray'>
          <visualize>0</visualize>
          <update_rate>40</update_rate>
          <ray>
            <scan>
              <horizontal>
                <samples>720</samples>
                <resolution>1</resolution>
                <min_angle>-3</min_angle>
                <max_angle>3</max_angle>
              </horizontal>
              <vertical>
                <samples>1</samples>
                <min_angle>0</min_angle>
                <max_angle>0</max_angle>
              </vertical>
            </scan>
            <range>
              <min>0.1</min>
              <max>30</max>
              <resolution>0.01</resolution>
            </range>
            <noise>
              <type>gaussian</type>
              <mean>0</mean>
              <stddev>0.01</stddev>
            </noise>
          </ray>
          <plugin name='gazebo_ros_head_hokuyo_controller' filename='libgazebo_ros_laser.so'>
            <topicName>/my_robot/laser/scan</topicName>
            <frameName>hokuyo_link</frameName>
            <robotNamespace>/</robotNamespace>
          </plugin>
          <pose>0.035 0 0.1135 0 -0 0</pose>
        </sensor>
        <sensor name='head_hokuyo_sensor' type='ray'>
          <visualize>0</visualize>
          <update_rate>40</update_rate>
          <ray>
            <scan>
              <horizontal>
                <samples>720</samples>
                <resolution>1</resolution>
                <min_angle>-3</min_angle>
                <max_angle>3</max_angle>
              </horizontal>
              <vertical>
                <samples>1</samples>
                <min_angle>0</min_angle>
                <max_angle>0</max_angle>
              </vertical>
            </scan>
            <range>
              <min>0.1</min>
              <max>30</max>
              <resolution>0.01</resolution>
            </range>
            <noise>
              <type>gaussian</type>
              <mean>0</mean>
              <stddev>0.01</stddev>
            </noise>
          </ray>
          <plugin name='gazebo_ros_head_hokuyo_controller' filename='libgazebo_ros_laser.so'>
            <topicName>/my_robot/laser/scan</topicName>
            <frameName>hokuyo_link</frameName>
            <robotNamespace>/</robotNamespace>
          </plugin>
          <pose>0.035 0 0.1135 0 -0 0</pose>
        </sensor>
        <self_collide>0</self_collide>
        <enable_wind>0</enable_wind>
        <kinematic>0</kinematic>
      </link>
      <joint name='left_wheel_hinge' type='revolute'>
        <pose relative_to='base_footprint'>0 0.063 0.032 0 -0 0</pose>
        <parent>base_footprint</parent>
        <child>left_wheel</child>
        <axis>
          <xyz>0 1 0</xyz>
          <limit>
            <effort>0</effort>
            <velocity>0</velocity>
            <lower>-1e+16</lower>
            <upper>1e+16</upper>
          </limit>
          <dynamics>
            <spring_reference>0</spring_reference>
            <spring_stiffness>0</spring_stiffness>
          </dynamics>
        </axis>
      </joint>
      <link name='left_wheel'>
        <pose relative_to='left_wheel_hinge'>0 0 0 0 -0 0</pose>
        <inertial>
          <pose>0 0 0 1.5708 -0 0</pose>
          <mass>0.05</mass>
          <inertia>
            <ixx>1.56167e-05</ixx>
            <ixy>0</ixy>
            <ixz>0</ixz>
            <iyy>1.56167e-05</iyy>
            <iyz>0</iyz>
            <izz>2.56e-05</izz>
          </inertia>
        </inertial>
        <collision name='left_wheel_collision'>
          <pose>0 0 0 1.5708 -0 0</pose>
          <geometry>
            <cylinder>
              <length>0.026</length>
              <radius>0.032</radius>
            </cylinder>
          </geometry>
          <surface>
            <contact>
              <ode>
                <kp>1e+07</kp>
                <kd>100</kd>
                <max_vel>1</max_vel>
                <min_depth>0.001</min_depth>
              </ode>
            </contact>
            <friction>
              <ode>
                <mu>1</mu>
                <mu2>1</mu2>
              </ode>
              <torsional>
                <ode/>
              </torsional>
            </friction>
            <bounce/>
          </surface>
          <max_contacts>10</max_contacts>
        </collision>
        <visual name='left_wheel_visual'>
          <pose>0 0 0 1.5708 -0 0</pose>
          <geometry>
            <mesh>
              <scale>1 1 1</scale>
              <uri>/root/catkin_ws/src/my_ROS_mobile_robot/my_robot_description/meshes/left_wheel.dae</uri>
            </mesh>
          </geometry>
          <material>
            <script>
              <name>Gazebo/FlatBlack</name>
              <uri>file://media/materials/scripts/gazebo.material</uri>
            </script>
          </material>
        </visual>
        <self_collide>0</self_collide>
        <enable_wind>0</enable_wind>
        <kinematic>0</kinematic>
      </link>
      <joint name='right_wheel_hinge' type='revolute'>
        <pose relative_to='base_footprint'>0 -0.063 0.032 0 -0 0</pose>
        <parent>base_footprint</parent>
        <child>right_wheel</child>
        <axis>
          <xyz>0 1 0</xyz>
          <limit>
            <effort>0</effort>
            <velocity>0</velocity>
            <lower>-1e+16</lower>
            <upper>1e+16</upper>
          </limit>
          <dynamics>
            <spring_reference>0</spring_reference>
            <spring_stiffness>0</spring_stiffness>
          </dynamics>
        </axis>
      </joint>
      <link name='right_wheel'>
        <pose relative_to='right_wheel_hinge'>0 0 0 0 -0 0</pose>
        <inertial>
          <pose>0 0 0 -1.5708 0 0</pose>
          <mass>0.05</mass>
          <inertia>
            <ixx>1.56167e-05</ixx>
            <ixy>0</ixy>
            <ixz>0</ixz>
            <iyy>1.56167e-05</iyy>
            <iyz>0</iyz>
            <izz>2.56e-05</izz>
          </inertia>
        </inertial>
        <collision name='right_wheel_collision'>
          <pose>0 0 0 -1.5708 0 0</pose>
          <geometry>
            <cylinder>
              <length>0.026</length>
              <radius>0.032</radius>
            </cylinder>
          </geometry>
          <surface>
            <contact>
              <ode>
                <kp>1e+07</kp>
                <kd>100</kd>
                <max_vel>1</max_vel>
                <min_depth>0.001</min_depth>
              </ode>
            </contact>
            <friction>
              <ode>
                <mu>1</mu>
                <mu2>1</mu2>
              </ode>
              <torsional>
                <ode/>
              </torsional>
            </friction>
            <bounce/>
          </surface>
          <max_contacts>10</max_contacts>
        </collision>
        <visual name='right_wheel_visual'>
          <pose>0 0 0 -1.5708 0 0</pose>
          <geometry>
            <mesh>
              <scale>1 1 1</scale>
              <uri>/root/catkin_ws/src/my_ROS_mobile_robot/my_robot_description/meshes/right_wheel.dae</uri>
            </mesh>
          </geometry>
          <material>
            <script>
              <name>Gazebo/FlatBlack</name>
              <uri>file://media/materials/scripts/gazebo.material</uri>
            </script>
          </material>
        </visual>
        <self_collide>0</self_collide>
        <enable_wind>0</enable_wind>
        <kinematic>0</kinematic>
      </link>
      <plugin name='gazebo_ros_control' filename='libgazebo_ros_control.so'>
        <robotNamespace>/my_robot</robotNamespace>
        <robotParam>/robot_description</robotParam>
        <robotSimType>gazebo_ros_control/DefaultRobotHWSim</robotSimType>
      </plugin>
      <plugin name='ground_truth' filename='libgazebo_ros_p3d.so'>
        <frameName>map</frameName>
        <topicName>my_robot/odom</topicName>
        <updateRate>30.0</updateRate>
        <gaussianNoise>0.0</gaussianNoise>
        <robotNamespace>/</robotNamespace>
        <bodyName>base_footprint</bodyName>
        <xyzOffset>0 0 0</xyzOffset>
        <rpyOffset>0 -0 0</rpyOffset>
        <ignition::corrected_offsets>1</ignition::corrected_offsets>
      </plugin>
      <plugin name='differential_drive_controller' filename='libgazebo_ros_diff_drive.so'>
        <robotNamespace>/</robotNamespace>
        <alwaysOn>1</alwaysOn>
        <updateRate>100</updateRate>
        <leftJoint>left_wheel_hinge</leftJoint>
        <rightJoint>right_wheel_hinge</rightJoint>
        <wheelSeparation>0.045</wheelSeparation>
        <wheelDiameter>0.064</wheelDiameter>
        <torque>60</torque>
        <commandTopic>my_robot/cmd_vel</commandTopic>
        <odometryTopic>my_robot/odom</odometryTopic>
        <odometryFrame>map</odometryFrame>
        <robotBaseFrame>base_footprint</robotBaseFrame>
        <legacyMode>0</legacyMode>
        <rosDebugLevel>Debug</rosDebugLevel>
        <publishWheelTF>1</publishWheelTF>
        <publishWheelJointState>1</publishWheelJointState>
        <wheelAcceleration>15</wheelAcceleration>
        <wheelTorque>60</wheelTorque>
        <maxLinearVelocity>3.0</maxLinearVelocity>
        <maxAngularVelocity>4.0</maxAngularVelocity>
        <publishTf>1</publishTf>
        <odometrySource>encoder</odometrySource>
      </plugin>
      <plugin name='imu_plugin' filename='libgazebo_ros_imu.so'>
        <alwaysOn>1</alwaysOn>
        <topicName>/my_robot/imu</topicName>
        <serviceName>imu_service</serviceName>
        <gaussianNoise>0.0</gaussianNoise>
        <updateRate>20.0</updateRate>
        <robotNamespace>/</robotNamespace>
        <bodyName>base_footprint</bodyName>
        <xyzOffset>0 0 0</xyzOffset>
        <rpyOffset>0 -0 0</rpyOffset>
        <ignition::corrected_offsets>1</ignition::corrected_offsets>
      </plugin>
      <plugin name='gazebo_ros_control' filename='libgazebo_ros_control.so'>
        <robotNamespace>/my_robot</robotNamespace>
        <robotParam>/robot_description</robotParam>
        <robotSimType>gazebo_ros_control/DefaultRobotHWSim</robotSimType>
      </plugin>
      <plugin name='ground_truth' filename='libgazebo_ros_p3d.so'>
        <frameName>map</frameName>
        <topicName>my_robot/odom</topicName>
        <updateRate>30.0</updateRate>
        <gaussianNoise>0.0</gaussianNoise>
        <robotNamespace>/</robotNamespace>
        <bodyName>base_footprint</bodyName>
        <xyzOffset>0 0 0</xyzOffset>
        <rpyOffset>0 -0 0</rpyOffset>
        <ignition::corrected_offsets>1</ignition::corrected_offsets>
      </plugin>
      <plugin name='differential_drive_controller' filename='libgazebo_ros_diff_drive.so'>
        <robotNamespace>/</robotNamespace>
        <alwaysOn>1</alwaysOn>
        <updateRate>100</updateRate>
        <leftJoint>left_wheel_hinge</leftJoint>
        <rightJoint>right_wheel_hinge</rightJoint>
        <wheelSeparation>0.045</wheelSeparation>
        <wheelDiameter>0.064</wheelDiameter>
        <torque>60</torque>
        <commandTopic>my_robot/cmd_vel</commandTopic>
        <odometryTopic>my_robot/odom</odometryTopic>
        <odometryFrame>map</odometryFrame>
        <robotBaseFrame>base_footprint</robotBaseFrame>
        <legacyMode>0</legacyMode>
        <rosDebugLevel>Debug</rosDebugLevel>
        <publishWheelTF>1</publishWheelTF>
        <publishWheelJointState>1</publishWheelJointState>
        <wheelAcceleration>15</wheelAcceleration>
        <wheelTorque>60</wheelTorque>
        <maxLinearVelocity>3.0</maxLinearVelocity>
        <maxAngularVelocity>4.0</maxAngularVelocity>
        <publishTf>1</publishTf>
        <odometrySource>encoder</odometrySource>
      </plugin>
      <plugin name='imu_plugin' filename='libgazebo_ros_imu.so'>
        <alwaysOn>1</alwaysOn>
        <topicName>/my_robot/imu</topicName>
        <serviceName>imu_service</serviceName>
        <gaussianNoise>0.0</gaussianNoise>
        <updateRate>20.0</updateRate>
        <robotNamespace>/</robotNamespace>
        <bodyName>base_footprint</bodyName>
        <xyzOffset>0 0 0</xyzOffset>
        <rpyOffset>0 -0 0</rpyOffset>
        <ignition::corrected_offsets>1</ignition::corrected_offsets>
      </plugin>
      <frame name='camera_joint' attached_to='chassis'>
        <pose>0.095 0 0.06 0 -0 0</pose>
      </frame>
      <frame name='camera_link' attached_to='camera_joint'/>
      <frame name='caster_joint' attached_to='chassis'>
        <pose>0 0 0 0 -0 0</pose>
      </frame>
      <frame name='caster_wheel' attached_to='caster_joint'/>
      <frame name='hokuyo_joint' attached_to='chassis'>
        <pose>0.035 0 0.1135 0 -0 0</pose>
      </frame>
      <frame name='hokuyo_link' attached_to='hokuyo_joint'/>
      <frame name='base_joint' attached_to='base_footprint'>
        <pose>0 0 0 0 -0 0</pose>
      </frame>
      <frame name='chassis' attached_to='base_joint'/>
      <pose>0 0 0.1 0 -0 0</pose>
    </model>
    <model name='House 2'>
      <static>1</static>
      <link name='link'>
        <collision name='collision'>
          <geometry>
            <mesh>
              <uri>model://house_2/meshes/house_2.dae</uri>
              <scale>1.5 1.5 1.5</scale>
            </mesh>
          </geometry>
          <max_contacts>10</max_contacts>
          <surface>
            <contact>
              <ode/>
            </contact>
            <bounce/>
            <friction>
              <torsional>
                <ode/>
              </torsional>
              <ode/>
            </friction>
          </surface>
        </collision>
        <visual name='visual'>
          <geometry>
            <mesh>
              <uri>model://house_2/meshes/house_2.dae</uri>
              <scale>1.5 1.5 1.5</scale>
            </mesh>
          </geometry>
          <material>
            <script>
              <uri>model://house_2/materials/scripts</uri>
              <uri>model://house_2/materials/textures</uri>
              <uri>model://house_1/materials/textures</uri>
              <name>House_2/Diffuse</name>
            </script>
            <shader type='normal_map_tangent_space'>
              <normal_map>model://house_1/materials/textures/House_1_Normal.png</normal_map>
            </shader>
          </material>
        </visual>
        <self_collide>0</self_collide>
        <enable_wind>0</enable_wind>
        <kinematic>0</kinematic>
      </link>
      <pose>-10.3147 -3.09443 0 0 -0 0</pose>
    </model>
    <model name='House 2_0'>
      <static>1</static>
      <link name='link'>
        <collision name='collision'>
          <geometry>
            <mesh>
              <uri>model://house_2/meshes/house_2.dae</uri>
              <scale>1.5 1.5 1.5</scale>
            </mesh>
          </geometry>
          <max_contacts>10</max_contacts>
          <surface>
            <contact>
              <ode/>
            </contact>
            <bounce/>
            <friction>
              <torsional>
                <ode/>
              </torsional>
              <ode/>
            </friction>
          </surface>
        </collision>
        <visual name='visual'>
          <geometry>
            <mesh>
              <uri>model://house_2/meshes/house_2.dae</uri>
              <scale>1.5 1.5 1.5</scale>
            </mesh>
          </geometry>
          <material>
            <script>
              <uri>model://house_2/materials/scripts</uri>
              <uri>model://house_2/materials/textures</uri>
              <uri>model://house_1/materials/textures</uri>
              <name>House_2/Diffuse</name>
            </script>
            <shader type='normal_map_tangent_space'>
              <normal_map>model://house_1/materials/textures/House_1_Normal.png</normal_map>
            </shader>
          </material>
        </visual>
        <self_collide>0</self_collide>
        <enable_wind>0</enable_wind>
        <kinematic>0</kinematic>
      </link>
      <pose>2.03559 -10.5242 0 0 -0 0</pose>
    </model>
    <state world_name='default'>
      <sim_time>315 392000000</sim_time>
      <real_time>800 643811352</real_time>
      <wall_time>1776446702 249791196</wall_time>
      <iterations>315392</iterations>
      <model name='House 2'>
        <pose>-10.3147 -3.09443 0 0 -0 0</pose>
        <scale>1 1 1</scale>
        <link name='link'>
          <pose>-10.3147 -3.09443 0 0 -0 0</pose>
          <velocity>0 0 0 0 -0 0</velocity>
          <acceleration>0 0 0 0 -0 0</acceleration>
          <wrench>0 0 0 0 -0 0</wrench>
        </link>
      </model>
      <model name='House 2_0'>
        <pose>2.03559 -10.5242 0 0 -0 0</pose>
        <scale>1 1 1</scale>
        <link name='link'>
          <pose>2.03559 -10.5242 0 0 -0 0</pose>
          <velocity>0 0 0 0 -0 0</velocity>
          <acceleration>0 0 0 0 -0 0</acceleration>
          <wrench>0 0 0 0 -0 0</wrench>
        </link>
      </model>
      <model name='ground_plane'>
        <pose>0 0 0 0 -0 0</pose>
        <scale>1 1 1</scale>
        <link name='link'>
          <pose>0 0 0 0 -0 0</pose>
          <velocity>0 0 0 0 -0 0</velocity>
          <acceleration>0 0 0 0 -0 0</acceleration>
          <wrench>0 0 0 0 -0 0</wrench>
        </link>
      </model>
      <model name='my_robot'>
        <pose>0.002218 -0.00023 -0.000992 0 -0.022373 0.004324</pose>
        <scale>1 1 1</scale>
        <link name='base_footprint'>
          <pose>0.002218 -0.00023 -0.000992 0 -0.022373 0.004324</pose>
          <velocity>-1.3e-05 -0 1e-06 -1e-06 -1.1e-05 -8e-06</velocity>
          <acceleration>-0 0 -0 0 -0 0</acceleration>
          <wrench>-0 0 -0 0 -0 0</wrench>
        </link>
        <link name='left_wheel'>
          <pose>0.001229 0.062767 0.031 -5e-06 -0.153199 0.004325</pose>
          <velocity>-1.3e-05 -0 0 2e-06 -0.000413 -8e-06</velocity>
          <acceleration>-0 0 0 0 -0 0</acceleration>
          <wrench>-0 0 0 0 -0 0</wrench>
        </link>
        <link name='right_wheel'>
          <pose>0.001774 -0.063232 0.031 4e-06 -0.162122 0.004323</pose>
          <velocity>-1.4e-05 -0 0 2e-06 -0.000446 -8e-06</velocity>
          <acceleration>0 0 -0 0 -0 0</acceleration>
          <wrench>0 0 -0 0 -0 0</wrench>
        </link>
      </model>
      <light name='sun'>
        <pose>0 0 10 0 -0 0</pose>
      </light>
    </state>
    <gui fullscreen='0'>
      <camera name='user_camera'>
        <pose>2.11882 5.41114 2.83285 0 0.321796 -2.159</pose>
        <view_controller>orbit</view_controller>
        <projection_type>perspective</projection_type>
      </camera>
    </gui>
  </world>
</sdf>
